# MAVRA Overleaf 工程

论文标题：**MAVRA: Shared Database Knowledge and Verified Experience for Data Agents**。

`main.tex` 是双语入口，`main-en.tex` 是英文入口，两者直接读取同一份 `paper.tex`。修改对应章节即可同时更新两种语言，不再生成或维护正文副本。本轮围绕用户侧智能体的共享知识与经验层重构正文，区分知识积累、验证策略选择和有效性维护；原指标实验保留为维护组件证据。

## 目录与编辑位置

| 路径 | 用途 |
| --- | --- |
| `main.tex` | 双语入口，只设置文档类与语言开关 |
| `main-en.tex` | 英文入口，只设置文档类与语言开关 |
| `main-details.tex` / `main-en-details.tex` | 可选扩展工作稿，正文及参考文献之后包含完整旧数据变化场景 |
| `paper.tex` | 标题、作者、文档环境与章节顺序 |
| `acmart.cls` | 随包提供的官方 ACM 文档类，不依赖编译环境预装此文件 |
| `latex/preamble.tex` | 宏包、语言宏、颜色、图表样式和数值宏加载 |
| `latex/acmart/acmart.dtx` | 官方文档类的对应源码，保留版权及 LPPL 许可说明 |
| `sections/abstract.tex` | 中英文摘要、关键词与 `\maketitle` |
| `sections/01-*.tex` 至 `10-*.tex` | 论文十个章节，共享记忆架构、知识模型、积累与反馈、维护及使用保证 |
| `sections/evaluation/` | 实验设置、固定库会话、匹配积累、策略选择、有效性、并发、修复与维护代价 |
| `figures/` | TikZ / pgfplots 图，包括标题与描述 |
| `tables/` | 实验与对照表，包括会话耗时表的标题和生成数据加载位置 |
| `references.tex` | 已核对的文献条目，引用键与条目顺序保持兼容 |
| `gen/` | 实验统计脚本生成的数值宏、表格数据和绘图坐标；不要手改 |
| `build.sh` | 编译或生成 Overleaf 上传包 |
| `mavra-sigmod-bilingual.zip` | 包含两个主稿入口、两个扩展入口、论文源码与 ACM 文档类；标准宏包和字体由 TeX 环境提供 |

章节中的 `\bi{English}{中文}`、标题与图表中的 `\bt{English}{中文}` 保持原用法。论文的 LaTeX 文件均在本目录内；在安装了所需宏包与字体的 TeX 环境中，编译不依赖父目录、实验数据或实验服务器。

## Overleaf 设置

1. 上传 `mavra-sigmod-bilingual.zip`，保留包内目录结构。
2. 双语稿：Main document 选择 `main.tex`，Compiler 选择 **XeLaTeX**。
3. 英文稿：Main document 选择 `main-en.tex`，Compiler 选择 **pdfLaTeX**，也可使用 XeLaTeX。

Overleaf 的编译器需要在项目设置中选择；源码顶部的 `% !TeX program` 注释不会自动改变这一设置。若使用 pdfLaTeX 编译双语入口 `main.tex`，应先改用 XeLaTeX。[官方编译器设置说明](https://docs.overleaf.com/getting-started/recompiling-your-project/selecting-a-tex-live-version-and-latex-compiler)。

上传包现已包含 `acmart.cls`，应放在与 `main.tex` 相同的项目根目录。模板使用 [CTAN / TeX Live 官方发行版](https://ctan.org/pkg/acmart) **2.20（2026-08-16）**，文件原样保留，随包携带对应的 `acmart.dtx` 源码。

保留 `\documentclass[sigconf,review,anonymous]{acmart}` 和模板原有排版。投稿格式参考 [SIGMOD 2027 Research 官方要求](https://2027.sigmod.org/calls_papers_sigmod_research.shtml)，最终页数应以投稿用编译器生成的 PDF 为准。`main-en.tex` 不包含扩展场景附录；扩展工作稿只供研究复核；其入口关闭末页自动栏平衡，以适配末尾跨栏浮动图表，主稿保持 ACM 默认设置。官方要求附录作为单独 PDF 上传，因此不能直接把扩展工作稿作为主稿提交。

## 编译与打包

在本目录执行：

```bash
./build.sh en    # 英文稿 → build/main-en.pdf
./build.sh bi    # 双语稿 → build/main.pdf
./build.sh all   # 两份都编译，默认选项
./build.sh details  # 编译两种语言的扩展工作稿
./build.sh pack  # 更新 mavra-sigmod-bilingual.zip，不需要 LaTeX 环境
```

编译优先使用 `latexmk`：英文调用 pdfLaTeX，双语调用 XeLaTeX；也支持已有的 Tectonic 环境。ACM 文档类已随包提供；环境仍需提供其标准宏包依赖、TikZ、pgfplots、colortbl，以及双语模式下的 `ctex` / Fandol 字体。打包只需要 Python 3，包含官方文档类及其源码，并按 `\input` 依赖收集论文文件，不包含实验附件、编译缓存或无关生成文件。构建不会改写论文源文件。

### 缺少标准宏包时

`acmart.cls` 成功加载后仍报 `xkeyval.sty` 等文件缺失，说明编译环境未安装对应宏包。类文件不能替代宏包和字体安装。使用 `latexmk` 且存在 `kpsewhich` 时，`build.sh` 会在编译前一次列出缺失的直接依赖和双语字体；这项预检不覆盖所有间接依赖。Overleaf 网页中的直接编译不会执行此脚本。

自建 Overleaf Community Edition 默认只有精简版 TeX Live。按照[官方安装说明](https://docs.overleaf.com/on-premises/installation/upgrading-tex-live)，管理员应在**实际编译容器**内补齐环境；使用 Overleaf Toolkit 时先执行 `bin/shell`，然后运行：

```bash
tlmgr install scheme-full
tlmgr path add
```

安装后可用 `kpsewhich xkeyval.sty`、`kpsewhich ctex.sty` 和 `kpsewhich FandolSong-Regular.otf` 检查是否返回文件路径。容器升级或重建时，应按官方说明保留完整 TeX 安装；Server Pro 的独立编译容器应按[对应镜像配置说明](https://docs.overleaf.com/on-premises/maintenance/extending-tex-live)处理。

如果使用官方 `overleaf.com`，可在项目设置中切换到另一年度 TeX Live 后重新编译；若仍缺少标准宏包，应交由平台排查编译环境。本地 TeX Live 则由其安装管理员通过包管理器补齐。Tectonic 会通过自己的资源包获取宏包，Tectonic 编译成功不能证明其他环境已安装相同依赖。

## 数值与实验存档

实验数据统一保存在仓库的 `exp/`，不再在 Overleaf 工程中保留副本。

| 生成文件 | 来源与生成脚本 |
| --- | --- |
| `gen/numbers.tex`、`gen/scen-*.tex` | `tools/paper-results.py`；原始场景结果在 noctis 的 `results/scen-20260930/`，汇总存档在 `exp/2026-10-01-scenarios/paper-results.json` |
| `gen/review.tex`、`gen/cache-ratio-*.tex`、`gen/snapshot-stress.tex` | `tools/review-results.py`；本地存档在 `exp/2026-10-02-cache-baseline-tpcds/` |
| `gen/session-latency.tex`、`gen/session-latency-table.tex` | `tools/session-latency-stats.py --tex-out overleaf/gen`；216 会话存档在 `exp/2026-10-03-session-latency/raw/`，固定定义库会话小节 |
| `gen/shared-memory*.tex`、`gen/strategy*.tex` | `tools/memory-study-stats.py`；三流消费者、三轮策略及元数据诊断存档在 `exp/2026-10-03-shared-memory/raw/` |
| 工作负载表中的数值 | `exp/2026-10-01-workload-characterization/` |

从仓库根目录重新生成实验输出：

```bash
python3 tools/paper-results.py --scen results/scen-20260930 --out overleaf/gen \
  --json exp/2026-10-01-scenarios/paper-results.json
python3 tools/review-results.py --exp exp/2026-10-02-cache-baseline-tpcds --out overleaf/gen
python3 tools/session-latency-stats.py exp/2026-10-03-session-latency/raw/dsv*/session-*/ \
  --out exp/2026-10-03-session-latency --tex-out overleaf/gen
python3 tools/memory-study-stats.py \
  --memory exp/2026-10-03-shared-memory/raw/results/shared-memory-recovery \
  --initial-memory exp/2026-10-03-shared-memory/raw/results/shared-memory-main \
  --strategy exp/2026-10-03-shared-memory/raw/results/strategy-main \
  --metadata exp/2026-10-03-shared-memory/raw/results/metadata-audit/report.json \
  --out exp/2026-10-03-shared-memory/analysis
```

场景生成命令需要服务器上完整的原始结果；正常编辑与编译不需要重新运行实验。研究状态与实现边界见 [docs/research-status.md](../docs/research-status.md)，实验索引见 [exp/README.md](../exp/README.md)，参考文献核对记录见 [docs/citation-audit-2026-10-01.md](../docs/citation-audit-2026-10-01.md)。

`overleaf/` 是主仓库的普通目录。上传包可以手动导入 Overleaf，目前未配置在线项目自动同步。

## 新增实验数据

[研究协议](../docs/shared-memory-study.md) 和 [审计结果](../exp/2026-10-03-shared-memory/analysis/results.md) 记录信息条件、原始失败、三个生产者流和三个策略计时重复。`tools/memory-study-stats.py` 从原始记录生成 `gen/shared-memory*.tex` 与 `gen/strategy*.tex`。主稿表格给出消费者每次尝试的代价，来源学习、提炼和完整检查采集单列；策略回放不代表一般智能体规划加速。

## 本轮验收版本（2026-10-03）

英文主稿 13 页，正文在第 12 页结束；双语主稿 20 页。旧场景的完整材料保留在扩展工作稿中。新增主比较提供相同业务定义：持续积累比隔离输入 token 低 24.4%、结构查找低 27.7%，比首轮冻结输入低 18.9%；四组均为 54/54。这是三个生产者流、一个合成领域及一个准确返回模型名约束下的描述性结果。原按量线路 28 次额度失败与完整恢复重复分别报告，不合并。

完整交付、测试与能力边界见 [验收报告](../docs/refactor-acceptance.md)。
