"""Compact grouped-bar comparison on the two analytical schemas.

Four setting groups retain the original equal-setting aggregation and run-range
error bars. Synthetic retail adds retrieval, self-verification, and full recheck
to the original no-memory/MAVRA pair; TPC-H plots its three executed methods.
All values come from the same archived runs, without additional experiments.
"""
import json
import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from matplotlib.patches import Patch
import mplstyle
import style

NAME = 'two-schemas'
W, H = style.COLUMN, 55.0
PHASES = {
    'holdout': ['holdout'],
    'benign': ['append', 'backfill', 'correct', 'addcol'],
    'modeled': ['status', 'revision', 'dupload', 'dimhist', 'latekey'],
    'all': ['holdout', 'append', 'backfill', 'correct', 'addcol', 'status',
            'revision', 'dupload', 'dimhist', 'latekey', 'unit', 'mirror'],
}
GROUPS = list(PHASES)
METHODS = ['middle', 'traj-global', 'traj-verify', 'metric-global-def', 'metric-global-snap']
KEYS = dict(zip(METHODS, ['NoShare', 'Traj', 'TrajVerify', 'Def', 'Cond']))
HATCHES = dict(zip(METHODS, ['////', r'\\\\', 'xx', '--', '....']))
PANELS = [
    (style.ROOT/'exp/2026-10-10-scenarios-q5/scen-stats.json', 'Ds', METHODS, 5),
    (style.ROOT/'exp/2026-10-11-generality/e2e/scen-stats.json', 'Ge',
     ['middle', 'traj-global', 'metric-global-snap'], 3),
]
TEXT = {
    'en': {
        'groups': ['Held-\nout', 'Non-\nbreaking', 'Covered\nbreaks', 'All\nsettings'],
        'panels': ['(a) Synthetic retail', '(b) TPC-H SF1'], 'y': 'Accuracy (%)',
        'methods': ['No memory', 'Retrieval', 'Retrieval + check', 'Full recheck', 'MAVRA'],
    },
    'zh': {
        'groups': ['留出题', '正常\n更新', '覆盖的\n破坏', '全部\n情形'],
        'panels': ['(a) 合成零售数据', '(b) TPC-H SF1'], 'y': '正确率（%）',
        'methods': ['无记忆', '示例检索', '检索 + 自行核验', '整定义重查', 'MAVRA'],
    },
}


def group_acc(runs, group):
    phases = PHASES[group]
    for r in runs:
        for p in phases:
            k, n = r['acc'][p]
            if not isinstance(k, int) or not isinstance(n, int) or not 0 <= k <= n or n == 0:
                raise ValueError(f'{p}: invalid scored-question counts')
    pooled = sum(sum(r['acc'][p][0] for r in runs) / sum(r['acc'][p][1] for r in runs)
                 for p in phases) / len(phases)
    per_run = [100 * sum(r['acc'][p][0] / r['acc'][p][1] for p in phases) / len(phases)
               for r in runs]
    return pooled * 100, per_run


def load():
    printed = {**style.macros('scen-ds'), **style.macros('generality')}
    panels = []
    for path, prefix, methods, repeats in PANELS:
        stats = json.loads(path.read_text(encoding='utf-8'))
        rows = {}
        for mode in methods:
            row = stats['methods'][mode]
            if len(row['runs']) != repeats:
                raise ValueError(f'{mode}: run count changed')
            rows[mode] = {g: group_acc(row['runs'], g) for g in GROUPS}
            for group, (value, _) in rows[mode].items():
                if not math.isclose(value, row[group]['acc'] * 100, abs_tol=1e-9):
                    raise ValueError(f'{mode}/{group}: aggregation mismatch')
                macro = f'{prefix}{KEYS[mode]}{group.capitalize()}'
                if macro in printed:
                    style.agree(macro, f'{value:.0f}', printed[macro])
        panels.append(rows)
    return panels


def figure(lang):
    T = TEXT[lang]
    panels = load()
    fig = mplstyle.figure(W, H)
    axes = fig.subplots(1, 2, sharey=True, gridspec_kw=dict(
        left=.12, right=.99, top=.79, bottom=.24, wspace=.20))
    handles = [Patch(**mplstyle.bar_style(m, HATCHES[m]), label=T['methods'][i])
               for i, m in enumerate(METHODS)]
    fig.legend(handles=handles, loc='upper center', bbox_to_anchor=(.53, .99),
               ncol=3, handlelength=1.1, columnspacing=.75, fontsize=6.5)
    for col, (ax, rows, (_, _, methods, _)) in enumerate(zip(axes, panels, PANELS)):
        width = .78 / len(methods)
        for mi, mode in enumerate(methods):
            values = [rows[mode][g][0] for g in GROUPS]
            lows = [min(rows[mode][g][1]) for g in GROUPS]
            highs = [max(rows[mode][g][1]) for g in GROUPS]
            xs = [i + (mi-(len(methods)-1)/2) * width for i in range(len(GROUPS))]
            ax.bar(xs, values, width=width, **mplstyle.bar_style(mode, HATCHES[mode]), zorder=2)
            ax.errorbar(xs, values, yerr=[[v-l for v, l in zip(values,lows)],
                                        [h-v for h,v in zip(highs,values)]],
                        fmt='none', ecolor='black', elinewidth=.4, capsize=.7,
                        capthick=.4, zorder=3)
        ax.set(xlim=(-.55, 3.55), ylim=(0,105), yticks=[0,25,50,75,100])
        ax.set_xticks(range(4), T['groups'])
        ax.tick_params(axis='x', length=0, labelsize=6.5)
        ax.yaxis.grid(True)
        box = ax.get_position()
        fig.text((box.x0+box.x1)/2, .025, T['panels'][col], ha='center', va='bottom', fontsize=7.5)
    axes[0].set_ylabel(T['y'], fontsize=7.5)
    return fig


if __name__ == '__main__':
    for path in style.build(sys.modules[__name__]):
        print(path)
