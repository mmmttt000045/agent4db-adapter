# MAVRA Overleaf 工程

论文标题：**MAVRA: Keeping Shared Metric Definitions Valid for Data Agents**。

`main.tex` 是双语入口，`main-en.tex` 是英文入口，两者直接读取同一份 `paper.tex`。修改对应章节即可同时更新两种语言，不再生成或维护正文副本。本次拆分保留原有正文、公式、图表、数值、引用顺序和排版设置。

## 目录与编辑位置

| 路径 | 用途 |
| --- | --- |
| `main.tex` | 双语入口，只设置文档类与语言开关 |
| `main-en.tex` | 英文入口，只设置文档类与语言开关 |
| `paper.tex` | 标题、作者、文档环境与章节顺序 |
| `acmart.cls` | 随包提供的官方 ACM 文档类，不依赖编译环境预装此文件 |
| `latex/preamble.tex` | 宏包、语言宏、颜色、图表样式和数值宏加载 |
| `latex/acmart/acmart.dtx` | 官方文档类的对应源码，保留版权及 LPPL 许可说明 |
| `sections/abstract.tex` | 中英文摘要、关键词与 `\maketitle` |
| `sections/01-*.tex` 至 `10-*.tex` | 原论文的十个章节，编号和顺序不变 |
| `sections/evaluation/` | 实验设置、有效性、并发、修复、维护代价与场景六个小节 |
| `figures/` | 四幅 TikZ / pgfplots 图，包括标题与描述 |
| `tables/` | 八张表，包括标题和原有生成数据的加载位置 |
| `references.tex` | 原样保留的 `thebibliography`，引用键与条目顺序不变 |
| `gen/` | 实验统计脚本生成的数值宏、表格数据和绘图坐标；不要手改 |
| `build.sh` | 编译或生成 Overleaf 上传包 |
| `mavra-sigmod-bilingual.zip` | 包含两个入口及其全部依赖的 Overleaf 源码包 |

章节中的 `\bi{English}{中文}`、标题与图表中的 `\bt{English}{中文}` 保持原用法。论文的 LaTeX 文件均在本目录内，不依赖父目录、实验数据或服务器即可编译。

## Overleaf 设置

1. 上传 `mavra-sigmod-bilingual.zip`，保留包内目录结构。
2. 双语稿：Main document 选择 `main.tex`，Compiler 选择 **XeLaTeX**。
3. 英文稿：Main document 选择 `main-en.tex`，Compiler 选择 **pdfLaTeX**，也可使用 XeLaTeX。

Overleaf 的编译器需要在项目设置中选择；源码顶部的 `% !TeX program` 注释不会自动改变这一设置。若使用 pdfLaTeX 编译双语入口 `main.tex`，应先改用 XeLaTeX。[官方编译器设置说明](https://docs.overleaf.com/getting-started/recompiling-your-project/selecting-a-tex-live-version-and-latex-compiler)。

上传包现已包含 `acmart.cls`，应放在与 `main.tex` 相同的项目根目录。模板使用 [CTAN / TeX Live 官方发行版](https://ctan.org/pkg/acmart) **2.20（2026-08-16）**，文件原样保留，随包携带对应的 `acmart.dtx` 源码。

保留 `\documentclass[sigconf,review,anonymous]{acmart}` 和模板原有排版。投稿格式参考 [SIGMOD 2027 Research 官方要求](https://2027.sigmod.org/calls_papers_sigmod_research.shtml)，最终页数应以投稿用编译器生成的 PDF 为准。

## 编译与打包

在本目录执行：

```bash
./build.sh en    # 英文稿 → build/main-en.pdf
./build.sh bi    # 双语稿 → build/main.pdf
./build.sh all   # 两份都编译，默认选项
./build.sh pack  # 更新 mavra-sigmod-bilingual.zip，不需要 LaTeX 环境
```

编译优先使用 `latexmk`：英文调用 pdfLaTeX，双语调用 XeLaTeX；也支持已有的 Tectonic 环境。ACM 文档类已随包提供；环境仍需提供其标准宏包依赖、TikZ、pgfplots、colortbl，以及双语模式下的 `ctex` / Fandol 字体。打包只需要 Python 3，包含官方文档类及其源码，并按 `\input` 依赖收集论文文件，不包含实验附件、编译缓存或无关生成文件。构建不会改写论文源文件。

## 数值与实验存档

实验数据统一保存在仓库的 `exp/`，不再在 Overleaf 工程中保留副本。

| 生成文件 | 来源与生成脚本 |
| --- | --- |
| `gen/numbers.tex`、`gen/scen-*.tex` | `tools/paper-results.py`；原始场景结果在 noctis 的 `results/scen-20260930/`，汇总存档在 `exp/2026-10-01-scenarios/paper-results.json` |
| `gen/review.tex`、`gen/cache-ratio-*.tex`、`gen/snapshot-stress.tex` | `tools/review-results.py`；本地存档在 `exp/2026-10-02-cache-baseline-tpcds/` |
| 工作负载表中的数值 | `exp/2026-10-01-workload-characterization/` |

从仓库根目录重新生成实验输出：

```bash
python3 tools/paper-results.py --scen results/scen-20260930 --out overleaf/gen \
  --json exp/2026-10-01-scenarios/paper-results.json
python3 tools/review-results.py --exp exp/2026-10-02-cache-baseline-tpcds --out overleaf/gen
```

场景生成命令需要服务器上完整的原始结果；正常编辑与编译不需要重新运行实验。研究状态与实现边界见 [docs/research-status.md](../docs/research-status.md)，实验索引见 [exp/README.md](../exp/README.md)，参考文献核对记录见 [docs/citation-audit-2026-10-01.md](../docs/citation-audit-2026-10-01.md)。

`overleaf/` 是主仓库的普通目录。上传包可以手动导入 Overleaf，目前未配置在线项目自动同步。
